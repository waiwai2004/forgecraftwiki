window.RELEASES = [
  {
    "id": 71,
    "tag_name": "v0.3.20",
    "prerelease": false,
    "published_at": "2026-11-09",
    "body": "锻造工艺 0.3.20\n\n1. BOSS 战调整至第 60 波；普通遭遇调整为第 15、25、33、41、46、51、56 波。\n2. 地精的口哨消耗由 20 金币调整为 40 金币，其余效果不变。\n3. 新游戏初始环境固定为「平平无奇」。\n4. 敌人每轮开始时确定行动招式；玩家中途攻击、改变敌人血线等不再使其临时换招。控制状态仍可阻止行动，增益与减益仍参与伤害计算；保存、读档保留本轮意图。\n5. 环境切换新增大图动画：先在画面中央放大展示天气图标，再缩小飞回左侧环境卡；与抽牌、事件、战斗转场依次衔接，避免画面重叠。\n\n沿用原包名与签名，支持覆盖安装并保留存档。\n",
    "assets": [
      {
        "name": "Forgecraft-0.3.20-release.apk",
        "size": 111471869,
        "sha256": "8eeda20133189259379587b3ba2ee27b2b60c8f0485f7333fcf8c12495fd8533",
        "browser_download_url": "https://forgecraftwiki-dac5o01m5.maozi.io/downloads/Forgecraft-0.3.20-release.apk"
      }
    ]
  }
];
